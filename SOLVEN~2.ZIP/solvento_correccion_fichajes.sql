-- =====================================================================
--  SOLVENTO / CERBERO — Corrección de fichajes y trazabilidad
--  Cambios en Supabase (PostgreSQL) para acompañar a los cambios de la app
-- =====================================================================
--
--  IMPORTANTE — LEE ESTO PRIMERO
--  ------------------------------------------------------------------
--  1) La parte MÁS importante de lo que pediste (que el ADMIN pueda
--     corregir cualquier fichaje con un motivo obligatorio y que quede
--     trazado y salga en el Excel) YA FUNCIONA SIN TOCAR LA BASE DE
--     DATOS. La app escribe la corrección directamente en
--     time_entries (check_in_at / check_out_at), guarda la traza en
--     la columna "flags" (JSON) y registra el cambio en time_entry_logs.
--     => Si solo quieres eso, NO necesitas ejecutar nada de este archivo.
--
--  2) Este SQL es necesario SOLO para la segunda parte: que el propio
--     TRABAJADOR pueda PROPONER una hora de entrada corregida (además de
--     la salida) desde "Solicitar ajuste". Esas funciones viven en tu
--     base de datos y NO estaban en el código que me pasaste, así que no
--     puedo ver su cuerpo actual. Por eso:
--       - El PASO 0 (introspección) es para que veas/exportes la
--         definición REAL de tus funciones antes de tocar nada.
--       - Los reemplazos van marcados como BORRADOR: ajústalos a tu
--         esquema real (o pásame el resultado del PASO 0 y te los dejo
--         exactos).
--
--  Ejecuta en el SQL Editor de Supabase. Haz una copia/backup antes.
-- =====================================================================


-- =====================================================================
-- PASO 0 — INTROSPECCIÓN (no modifica nada; ejecútalo y guarda la salida)
-- =====================================================================

-- 0.1 — Definición actual de las 3 funciones implicadas:
SELECT p.proname AS funcion,
       pg_get_function_identity_arguments(p.oid) AS argumentos,
       pg_get_functiondef(p.oid) AS definicion
FROM pg_proc p
JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE p.proname IN (
  'request_time_entry_adjustment',
  'admin_pending_adjustments',
  'resolve_time_entry_adjustment'
)
ORDER BY p.proname;

-- 0.2 — Estructura de la tabla de ajustes manuales
--       (ajusta el nombre si en tu base no se llama así):
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'time_entry_adjustments'   -- <-- VERIFICA este nombre
ORDER BY ordinal_position;


-- =====================================================================
-- PASO 1 — COLUMNA NUEVA (seguro e idempotente)
--          Guarda la hora de ENTRADA propuesta por el trabajador.
-- =====================================================================
-- Cambia "time_entry_adjustments" por el nombre real si fuera distinto.
ALTER TABLE public.time_entry_adjustments
  ADD COLUMN IF NOT EXISTS proposed_check_in timestamptz;


-- =====================================================================
-- PASO 2 — request_time_entry_adjustment  (BORRADOR — adáptalo)
--          Añade el parámetro p_proposed_check_in y lo guarda.
-- =====================================================================
-- NOTA: añadir un parámetro cambia la firma; por eso hay un DROP de la
-- firma antigua. Revisa con el PASO 0 los tipos y el cuerpo reales.

-- Firma antigua (ajusta los tipos si difieren):
DROP FUNCTION IF EXISTS public.request_time_entry_adjustment(uuid, timestamptz, text);

CREATE OR REPLACE FUNCTION public.request_time_entry_adjustment(
  p_time_entry_id    uuid,
  p_proposed_check_in  timestamptz,   -- NUEVO (puede llegar NULL)
  p_proposed_check_out timestamptz,
  p_reason           text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.time_entry_adjustments (
    time_entry_id,
    requested_by,
    proposed_check_in,
    proposed_check_out,
    reason,
    status,
    created_at
  )
  VALUES (
    p_time_entry_id,
    auth.uid(),
    p_proposed_check_in,
    p_proposed_check_out,
    p_reason,
    'pending',
    now()
  );
END;
$$;


-- =====================================================================
-- PASO 3 — admin_pending_adjustments  (BORRADOR — adáptalo)
--          Devuelve también proposed_check_in para que el admin lo vea
--          prerellenado en la pantalla de incidencias.
-- =====================================================================
-- Cambiar columnas de una función que devuelve TABLE exige recrearla.
DROP FUNCTION IF EXISTS public.admin_pending_adjustments(uuid);

CREATE OR REPLACE FUNCTION public.admin_pending_adjustments(
  p_company_id uuid
)
RETURNS TABLE (
  adjustment_id      uuid,
  time_entry_id      uuid,
  user_id            uuid,
  check_in_at        timestamptz,
  proposed_check_in  timestamptz,   -- NUEVO
  proposed_check_out timestamptz,
  reason             text,
  created_at         timestamptz
)
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT
    a.id                AS adjustment_id,
    a.time_entry_id,
    te.user_id,
    te.check_in_at,
    a.proposed_check_in,           -- NUEVO
    a.proposed_check_out,
    a.reason,
    a.created_at
  FROM public.time_entry_adjustments a
  JOIN public.time_entries te ON te.id = a.time_entry_id
  WHERE te.company_id = p_company_id
    AND a.status = 'pending';
$$;


-- =====================================================================
-- PASO 4 — resolve_time_entry_adjustment  (BORRADOR — adáptalo)
--          Añade p_final_check_in. Al VALIDAR, aplica la entrada y/o
--          salida corregidas a time_entries, deja traza en flags
--          (para el Excel) y marca el ajuste como resuelto.
-- =====================================================================
DROP FUNCTION IF EXISTS public.resolve_time_entry_adjustment(uuid, text, text, timestamptz);

CREATE OR REPLACE FUNCTION public.resolve_time_entry_adjustment(
  p_adjustment_id    uuid,
  p_decision         text,           -- 'validated' | 'rejected'
  p_resolution_reason text,
  p_final_check_in   timestamptz,    -- NUEVO (NULL = no cambiar entrada)
  p_final_check_out  timestamptz     -- NULL = no cambiar salida
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_entry_id   uuid;
  v_old_in     timestamptz;
  v_old_out    timestamptz;
  v_flags      jsonb;
BEGIN
  -- Localiza el fichaje afectado
  SELECT a.time_entry_id INTO v_entry_id
  FROM public.time_entry_adjustments a
  WHERE a.id = p_adjustment_id;

  IF v_entry_id IS NULL THEN
    RAISE EXCEPTION 'Ajuste % no encontrado', p_adjustment_id;
  END IF;

  SELECT te.check_in_at, te.check_out_at, COALESCE(te.flags, '{}'::jsonb)
    INTO v_old_in, v_old_out, v_flags
  FROM public.time_entries te
  WHERE te.id = v_entry_id;

  -- Marca el ajuste como resuelto (cambia los nombres de columna si difieren)
  UPDATE public.time_entry_adjustments
     SET status            = p_decision,
         resolution_reason = p_resolution_reason,
         resolved_at       = now(),
         resolved_by       = auth.uid()
   WHERE id = p_adjustment_id;

  IF p_decision = 'validated' THEN
    -- Aplica entrada/salida corregidas y deja traza en flags
    UPDATE public.time_entries
       SET check_in_at  = COALESCE(p_final_check_in, check_in_at),
           check_out_at = COALESCE(p_final_check_out, check_out_at),
           workflow_status = 'adjusted',
           flags = v_flags
                  || jsonb_build_object(
                       'admin_manual_edit', true,
                       'admin_edit_reason', p_resolution_reason,
                       'admin_edit_at', now(),
                       'admin_edit_by', auth.uid(),
                       'admin_old_check_in_at', v_old_in,
                       'admin_new_check_in_at',
                         CASE WHEN p_final_check_in IS NOT NULL
                              THEN p_final_check_in ELSE NULL END,
                       'admin_old_check_out_at', v_old_out,
                       'admin_new_check_out_at',
                         CASE WHEN p_final_check_out IS NOT NULL
                              THEN p_final_check_out ELSE NULL END
                     )
     WHERE id = v_entry_id;
  ELSE
    -- Rechazado: el trabajador debe enviar nueva propuesta
    UPDATE public.time_entries
       SET workflow_status = 'requires_new_proposal'
     WHERE id = v_entry_id;
  END IF;

  -- Registro inmutable del cambio
  INSERT INTO public.time_entry_logs (
    company_id, time_entry_id, action, performed_by, performed_role,
    old_values, new_values
  )
  SELECT te.company_id, v_entry_id,
         'manual_adjustment_' || p_decision,
         auth.uid(), 'admin',
         jsonb_build_object('check_in_at', v_old_in, 'check_out_at', v_old_out),
         jsonb_build_object(
           'check_in_at', COALESCE(p_final_check_in, v_old_in),
           'check_out_at', COALESCE(p_final_check_out, v_old_out),
           'reason', p_resolution_reason)
  FROM public.time_entries te
  WHERE te.id = v_entry_id;
END;
$$;

-- =====================================================================
-- FIN. Tras ejecutar, prueba el flujo de "Solicitar ajuste" del
-- trabajador y la validación en la pantalla de incidencias del admin.
-- =====================================================================
